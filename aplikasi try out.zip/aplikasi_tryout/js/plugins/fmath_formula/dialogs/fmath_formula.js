//-------------------------------------------------------------
//	Created by: Ionel Alexandru 
//	Mail: ionel.alexandru@gmail.com
//	Site: www.fmath.info
//---------------------------------------------------------------

(function()
{

	CKEDITOR.dialog.add( 'fmath_formula', function( editor )
	{
              return {
                 title : 'Mathml Editor',
                 minWidth : 850,
                 minHeight : 470,
                 //buttons: [],
                 contents :
                       [
                          {
                             id : 'iframe',
                             label : 'Mathml Editor',
                             expand : true,
                             elements :
                                   [
                                      {
				       type : 'html',
				       id : 'pageMathMLEmbed',
				       label : 'Mathml Editor',
				       html : '<div style="width:860px;height:430px"><iframe src="'+ CKEDITOR.plugins.getPath('fmath_formula') +'dialogs/editor.html" frameborder="0" name="iframeMathmlEditor" id="iframeMathmlEditor" allowtransparency="1" style="width:760px;height:420px;margin:0;padding:0;" scrolling="yes"></iframe></div>'
				      }
                                   ]
                          }
                       ],
		onOk : function()
		{
			var frame = document.getElementById('iframeMathmlEditor').contentWindow;
			frame.saveImage(editor);
			return false;
                 },
		onHide : function()
		{
			var frame = document.getElementById('iframeMathmlEditor');
			frame.src = CKEDITOR.plugins.getPath('fmath_formula') +'dialogs/editor.html';
		}
              };
        } );
			
})();



