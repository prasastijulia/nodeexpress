ALTER TABLE  `nilai` ADD  `jml_benar` TINYINT NOT NULL ,
ADD  `jml_salah` TINYINT NOT NULL 
