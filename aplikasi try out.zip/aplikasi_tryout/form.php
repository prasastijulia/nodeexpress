<h3>Import Data Siswa</h3>
 
<form method="post" enctype="multipart/form-data" action="proses.php">
Unggah File Excel : <input name="userfile" type="file">
<input name="upload" type="submit" value="Import">
</form>
